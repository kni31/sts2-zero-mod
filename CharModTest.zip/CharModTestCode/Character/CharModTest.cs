﻿using BaseLib.Abstracts;
using BaseLib.Utils.NodeFactories;
using CharModTest.CharModTestCode.Extensions;
using Godot;
using MegaCrit.Sts2.Core.Entities.Characters;
using MegaCrit.Sts2.Core.Models;
using MegaCrit.Sts2.Core.Models.Cards;
using MegaCrit.Sts2.Core.Models.Relics;
using CharModTest.CharModTestCode.Cards.Basic;
using CharModTest.CharModTestCode.Cards;
using CharModTest.CharModTestCode.Relics;

namespace CharModTest.CharModTestCode.Character;

public class CharModTest : PlaceholderCharacterModel
{
    public const string CharacterId = "CharModTest";
    
    public static readonly Color Color = new("ffffff");

    public override Color NameColor => Color;
    public override CharacterGender Gender => CharacterGender.Neutral;
    public override int StartingHp => 88;
    
    public override IEnumerable<CardModel> StartingDeck => [
        ModelDb.Card<Defendzero>(),
        ModelDb.Card<Defendzero>(),
        ModelDb.Card<Defendzero>(),
        ModelDb.Card<Defendzero>(),
        ModelDb.Card<Strikezero>(),
        ModelDb.Card<Strikezero>(),
        ModelDb.Card<Strikezero>(),
        ModelDb.Card<Strikezero>()
    ];

    public override IReadOnlyList<RelicModel> StartingRelics =>
    [
        ModelDb.Relic<ZeroRelic>()
    ];
    
    public override CardPoolModel CardPool => ModelDb.CardPool<CharModTestCardPool>();
    public override RelicPoolModel RelicPool => ModelDb.RelicPool<CharModTestRelicPool>();
    public override PotionPoolModel PotionPool => ModelDb.PotionPool<CharModTestPotionPool>();
    
    /*  PlaceholderCharacterModel will utilize placeholder basegame assets for most of your character assets until you
        override all the other methods that define those assets. 
        These are just some of the simplest assets, given some placeholders to differentiate your character with. 
        You don't have to, but you're suggested to rename these images. */
    public override Control CustomIcon
    {
        get
        {
            var icon = NodeFactory<Control>.CreateFromResource(CustomIconTexturePath);
            icon.SetAnchorsAndOffsetsPreset(Control.LayoutPreset.FullRect);
            return icon;
        }
    }
    public override string CustomIconTexturePath => "character_icon_char_name.png".CharacterUiPath();
    public override string CustomCharacterSelectIconPath => "char_select_char_name.png".CharacterUiPath();
    public override string CustomCharacterSelectLockedIconPath => "char_select_char_name_locked.png".CharacterUiPath();
    public override string CustomMapMarkerPath => "map_marker_char_name.png".CharacterUiPath();
}